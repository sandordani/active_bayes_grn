java -Xmx512M -jar SynTReN.jar

